# CatAndMouse > 2025-12-04 10:37am
https://universe.roboflow.com/korsh624/catandmouse

Provided by a Roboflow user
License: CC BY 4.0

