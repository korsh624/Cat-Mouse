Origin: https://github.com/google/flatbuffers/tree/v25.9.23
